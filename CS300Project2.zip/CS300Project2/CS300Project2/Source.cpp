/*
Pravishna Nand
CS 300 - Analysis and Design
7-1 Project Two
12/10/23
*/



#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

// Define a structure for a course
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Define a hash table to store course information
unordered_map<string, Course> courseTable;

// Function to load course data from a file into the hash table
void loadCourseData(const string& filename) {
    ifstream file(filename);
    if (!file) {
        cout << "Error: File not found." << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;

        size_t pos = line.find(',');
        if (pos == string::npos) {
            cout << "Skipping invalid course data: " << line << endl;
            continue;
        }

        string courseNumber = line.substr(0, pos);
        string rest = line.substr(pos + 1);

        pos = rest.find(',');
        if (pos == string::npos) {
            cout << "Skipping invalid course data: " << line << endl;
            continue;
        }

        string courseTitle = rest.substr(0, pos);
        string prerequisitesStr = rest.substr(pos + 1);

        Course course;
        course.courseNumber = courseNumber;
        course.courseTitle = courseTitle;

        // Split prerequisites by ',' and store them in the vector
        size_t start = 0;
        while (start < prerequisitesStr.length()) {
            pos = prerequisitesStr.find(',', start);
            if (pos == string::npos) {
                pos = prerequisitesStr.length();
            }
            string prerequisite = prerequisitesStr.substr(start, pos - start);
            course.prerequisites.push_back(prerequisite);
            start = pos + 1;
        }

        courseTable[courseNumber] = course;
    }

    file.close();
    cout << "Course data loaded successfully." << endl;
}

// Function to print a list of courses in alphanumeric order
void printCourseList() {
    if (courseTable.empty()) {
        cout << "Course data is not loaded. Please load data first (Option 1)." << endl;
        return;
    }

    vector<string> courseNumbers;
    for (const auto& entry : courseTable) {
        courseNumbers.push_back(entry.first);
    }
    sort(courseNumbers.begin(), courseNumbers.end());

    cout << "Here is a sample schedule:" << endl;
    for (const string& courseNumber : courseNumbers) {
        cout << courseNumber << ", " << courseTable[courseNumber].courseTitle << endl;
    }
}

// Function to print course information and prerequisites
void printCourseInfo(const string& courseNumber) {
    if (courseTable.empty()) {
        cout << "Course data is not loaded. Please load data first (Option 1)." << endl;
        return;
    }

    // Convert courseNumber to uppercase
    string uppercaseCourseNumber = courseNumber;
    transform(uppercaseCourseNumber.begin(), uppercaseCourseNumber.end(), uppercaseCourseNumber.begin(), ::toupper);

    if (courseTable.find(uppercaseCourseNumber) == courseTable.end()) {
        cout << "Error: Course not found." << endl;
        return;
    }

    const Course& course = courseTable[uppercaseCourseNumber];

    cout << course.courseNumber << ", " << course.courseTitle << endl;
    if (!course.prerequisites.empty()) {
        cout << "Prerequisites:" << endl;
        for (const string& prerequisite : course.prerequisites) {
            cout << prerequisite << ", " << courseTable[prerequisite].courseTitle << endl;
        }
    }
    else {
        cout << "No prerequisites for this course." << endl;
    }
}

int main() {
    cout << "Welcome to the course planner." << endl;
    bool dataLoaded = false;

    while (true) {
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << "What would you like to do? ";

        int choice;
        cin >> choice;

        switch (choice) {
        case 1: {
            string filename = "course.txt.txt";
            loadCourseData(filename);
            dataLoaded = true;
            break;
        }
        case 2:
            if (dataLoaded) {
                printCourseList();
            }
            else {
                cout << "Course data is not loaded. Please load data first (Option 1)." << endl;
            }
            break;
        case 3: {
            string courseNumber;
            cout << "What course do you want to know about? ";
            cin >> courseNumber;
            if (dataLoaded) {
                printCourseInfo(courseNumber);
            }
            else {
                cout << "Course data is not loaded. Please load data first (Option 1)." << endl;
            }
            break;
        }
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            return 0;
        case 4:  // Exit the program
            cout << "Thank you for using the course planner!" << endl;
            return 0;
        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }

    return 0;
}